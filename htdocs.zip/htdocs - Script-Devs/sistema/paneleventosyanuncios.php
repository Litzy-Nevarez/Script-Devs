<?php
		echo "
		<span id='perfil' style='position:absolute;top:120px;left:400px;width:calc(100% - 800px);min-height:500px;min-width:300px;z-index:400'>
			<h2 align='center'>Eventos y anuncios</h2>

			<hr style='height:3px;color:#5A0202;background-color:#5A0202'>
			<br>
			<table style='font-size:18px'>
				<tbody>
					<tr>
						<td>
							<img src='imagenes/perfil.png' height='60px'>
						</td>
						<td>
						<b style='font-size:25px'>Unidad de Vinculación ITD</b>
							<br>
							Eventos y anuncios
						</td>
					</tr>
				</tbody>
			</table>
			<p style='color:black'>Alumnos interesados en realizar su residencia profesional en Canadá favor de contactarse al correo de vinculación bajo el asunto de \"RP Canadá 2022\".</p>

			<hr style='height:3px;color:#5A0202;background-color:#5A0202'>
			<br>
			<table style='font-size:18px'>
				<tbody>
					<tr>
						<td>
							<img src='imagenes/perfil.png' height='60px'>
						</td>
						<td>
						<b style='font-size:25px'>ACISTI</b>
							<br>
							Eventos y anuncios
						</td>
					</tr>
				</tbody>
			</table>
			<p style='color:black'>Inscríbete al Hackathon de noviembre, 2022.<br>Descripción del evento: https://hackathonpagina.org<br>Costo de inscripción por equipo: $300</p>
			<table style='width:100%;'>
				<tbody>
					<tr>
						<td>
							<button id='volver' style='background-color:#5A0202;font-size:20px;min-width:160px;min-height:40px'><a style='color:white;text-decoration:none' href='sistema/eventoregistro.php''>Inscribirse</button></a><br>
						</td>
					</tr>
				</tbody>
			</table>

			<hr style='height:3px;color:#5A0202;background-color:#5A0202'>
			<br>
			<table style='font-size:18px'>
				<tbody>
					<tr>
						<td>
							<img src='imagenes/perfil.png' height='60px'>
						</td>
						<td>
						<b style='font-size:25px'>Departamento de Sistemas y Computación</b>
							<br>
							Eventos y anuncios
						</td>
					</tr>
				</tbody>
			</table>
			<p style='color:black'>Se suspenderán las clases los próximos días miércoles y jueves. Esto para no afectar a los alumnos que asistan a los intertecnológicos..</p>

		</span>
		";
?>