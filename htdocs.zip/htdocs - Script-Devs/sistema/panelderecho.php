<?php
		echo "
		<span id='mensajes' style='position:fixed;top:120px;left:calc(100% - 360px);width:350px;min-height:500px;visibility:visible'><p align='center' style='font-size:40px;'><b>Mensajes</b></p></span>
		<span id='circulos' style='position:fixed;top:120px;left:calc(100% - 360px);width:350px;min-height:500px;visibility:hidden'><p align='center' style='font-size:40px;'><b>Círculos</b></p></span>
		<span id='notificaciones' style='position:fixed;top:120px;left:calc(100% - 360px);width:350px;min-height:500px;visibility:hidden'><p align='center' style='font-size:40px;'><b>Notificaciones</b></p></span>
		";
?>