<?php
	echo '
		</body>
	</html>';
?>