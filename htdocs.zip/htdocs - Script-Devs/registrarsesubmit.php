<?php

	$con = mysqli_connect("localhost","scriptdevs","scriptdevs123","scriptdevs");
	session_start();
	$usuario = $_POST["usuario"];
	$pass = $_POST["pass"];
	$idSesion = session_id();
	$sql = "SELECT * FROM usuarios WHERE usuario = '$usuario'";
	$rs = mysqli_query($con,$sql);
	if($rs->num_rows > 0)
	{
		include 'sistema/encabezado.php';
		echo "
		<br><br><br><br><h2>Número de control ya registrado. Inténtelo de nuevo con otro número o póngase en contacto con un administrador.</h2>";
	}
	else
	{
		$sql = "INSERT INTO usuarios (usuario, contrasena, idSesion) VALUES ('$usuario', '$pass', '$idSesion')";
		$rs = mysqli_query($con,$sql);
		include 'sistema/encabezado.php';
		if($rs)
		{
			header('Location:inicio.php');
			exit();
		}
	}
	include 'sistema/pie.php';
?>